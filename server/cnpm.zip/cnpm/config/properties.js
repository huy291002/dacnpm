module.exports = {
    PORT : 3001,
    DB : 'mongodb+srv://huyle252:family9788vn@cluster0.ote7who.mongodb.net/test',
    CORS : ['http://localhost:3000']
  }